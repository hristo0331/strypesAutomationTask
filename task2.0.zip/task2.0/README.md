1. Open the main folder "taskToDo" in VSCode
2. Open the terminal and execute:
    npm install
3. In terminal execute:
    npm test