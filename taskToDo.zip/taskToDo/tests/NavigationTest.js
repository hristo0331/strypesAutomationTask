import { Builder, By } from 'selenium-webdriver';
import { expect } from 'chai';
import 'chromedriver';

describe('Navigation Tests', function () {
    this.timeout(10000);
    let driver;

    before(async function () {
        driver = await new Builder().forBrowser('chrome').build();
        await driver.get('https://ict-strypes.eu/');
    });

    after(async function () {
        await driver.quit();
    });

    it('should navigate to the Customers page', async function () {
        const customerPage = driver.findElement(By.xpath('//*[@id="menu-1-50af2d3b"]/li[4]/a'))
        await customerPage.click();
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.equal('https://ict-strypes.eu/customers/'); 
    });

    it('should navigate to the Nearsurance page', async function () {
        const nearsurancePage = driver.findElement(By.xpath('//*[@id="menu-1-50af2d3b"]/li[5]/a'))
        await nearsurancePage.click();
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.equal('https://ict-strypes.eu/nearsurance/'); 
    });
});