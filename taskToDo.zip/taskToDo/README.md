1. Open the main folder "taskToDo" in VSCode
2. Open the terminal and execute:
    npm init -y
    npm install selenium-webdriver
    npm install mocha chai
    npm install chromedriver
3. In terminal execute:
    npm test