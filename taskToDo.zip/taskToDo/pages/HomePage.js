import { By } from 'selenium-webdriver';

class HomePage {
    constructor(driver) {
        this.driver = driver;
        this.url = 'https://ict-strypes.eu/';
    }

    async open() {
        await this.driver.get(this.url);
    }

    async getTitle() {
        return this.driver.getTitle();
    }

    async isNavLinkPresent(linkText) {
        const link = await this.driver.findElement(By.linkText(linkText));
        return link.isDisplayed();
    }

    async isImageDisplayed(imageSelector) {
        const image = await this.driver.findElement(By.css(imageSelector));
        return image.isDisplayed();
    }

    async goToInvalidURL() {
        await this.driver.get('https://ict-strypes.eu/homee');
    }
}

export default HomePage;
