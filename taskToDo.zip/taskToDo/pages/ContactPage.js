import { By } from 'selenium-webdriver';

class ContactPage {
    constructor(driver) {
        this.driver = driver;
    }

    async open() {
        await this.driver.get('https://ict-strypes.eu/contact/');
    }

    async fillField(placeholder, value) {
        await this.driver.findElement(By.xpath(`//*[@placeholder="${placeholder}"]`)).sendKeys(value);
    }

    async submitContactForm(firstName, lastName, email, companyName, message) {
        await this.fillField('First name:', firstName);
        await this.fillField('Last name:', lastName);
        await this.fillField('E-mail:*', email);
        await this.fillField('Company name:', companyName);
        await this.fillField('Messages:', message);
        
        // check-box
        await this.driver.findElement(By.id("LEGAL_CONSENT.subscription_type_4681882-9246f6ce-b893-4249-8362-96d17c0861f5")).click();

        // send button
        await this.driver.findElement(By.css('#hsForm_9246f6ce-b893-4249-8362-96d17c0861f5 input[type="submit"]')).click();
    }

    
}

export default ContactPage;
