import { By, Key } from 'selenium-webdriver';

class SearchPage {
    constructor(driver) {
        this.driver = driver;
    }

    async performSearch(query) {
        await this.driver.findElement(By.xpath('//*[@id="header_pop"]/div/div/div/section[1]/div/div[2]/div/div/div/search/form/div[1]/i')).click();
        
        const searchField = await this.driver.findElement(By.xpath('//input[@type="search"]'));
        await searchField.sendKeys(query);
        await searchField.sendKeys(Key.ENTER);
    }
}

export default SearchPage;
